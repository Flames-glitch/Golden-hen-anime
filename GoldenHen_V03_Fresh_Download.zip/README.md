# Golden Hen v0.3 — Android anime browser and player

Kotlin/Jetpack Compose Android app, dark-and-gold theme, Aurora Media-style Media3 player.

## Changes since v0.2

* User-supplied golden rooster integrated as the launcher and adaptive icon.
* One-tap native discovery groups: All, Airing, Series, Movies, OVAs, Specials, ONAs. Genres, status, year, popularity and search remain supported. The native metadata catalog uses AniList and paginates; it is **not** a replica of any website's content inventory.
* **Animepahe** tab opens website pages inside an Android WebView. Both user-confirmed hostnames `animepahe.ng` and `animepahe.ch` are available to switch manually. An **Open in browser** fallback is included for sites that block embedded browsing.
* Basic domain health/redirect check runs when opening the tab or pressing **Check domain**. It reports HTTP errors or redirects; it does not invent new mirror domains or autonomously track changes while the app is closed.
* Anime details provide **Find available episodes on Animepahe**. The selected title is shown with a Copy button to help search on the site.
* Preserved existing optional **user-supplied authorized stream** queue and standalone Media3 player with gestures, resume, picture-in-picture and audio/subtitle selection where available.

## Very important: content and episode limitations

This project **does not scrape or import every title or episode from Animepahe**. It does not download or host Animepahe's media. The website tab presents the **website's own live listings**, including episodes *available on that site*; its playback uses the site's web player, NOT Media3. The native AniList screen does not know whether a particular episode has been released, is available at the site, or is playable. AniList's `episodes` field is a reported series total, not a downloadable episode listing. A verified, permitted catalog/episode provider API must be integrated before native automatic episode lists or automatic Media3 playback of provider content can be offered.

Changing the domain: the two supplied domains are selectable. If one redirects to an unexpected hostname, Golden Hen shows that fact for manual review. Do not assume a redirect target is official or automatically update to it.

The user-provided domains have not been independently checked online in this workspace, and website playback may be blocked by browser protection, network restrictions or changes to the site.

## Android build (phone users who upload ZIP directly)

1. Upload `GoldenHen_v0.3_GitHub_Source.zip` as a **file** to the root of the existing repository. Old V1/V2 ZIPs may remain; the workflow prefers V0.3.
2. Copy `GoldenHen_v0.3_main.yml` to `.github/workflows/main.yml` using GitHub's Edit button (do not upload the YAML only as an archive).
3. Go to **Actions → Build Golden Hen APK** and run it. The workflow extracts V0.3 from the ZIP before invoking Gradle.
4. If compilation succeeds, open the workflow run's **Artifacts** section for `GoldenHen-v0.3-debug-apk`.

Alternatively, unzip the project locally and upload its contents; the workflow also handles an extracted Gradle root.

## Build verification

Static project structure, generated icon resources and ZIP are checked. Actual Android compilation and playback are **not tested** in this environment; the GitHub Actions run is the first real Gradle/Android SDK compilation check.
