package com.goldenhen.anime

import android.app.DownloadManager
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.text.Html
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** AniList supplies metadata only, not licensed episode streaming links. */
data class Anime(
    val id: Int,
    val title: String,
    val image: String,
    val banner: String,
    val description: String,
    val year: Int,
    val score: Int,
    val episodes: Int,
    val format: String,
    val status: String,
    val genres: List<String>
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("title", title); put("image", image); put("banner", banner)
        put("description", description); put("year", year); put("score", score)
        put("episodes", episodes); put("format", format); put("status", status)
        put("genres", JSONArray(genres))
    }
    companion object {
        fun fromJson(o: JSONObject) = Anime(
            id = o.optInt("id"), title = o.optString("title"), image = o.optString("image"),
            banner = o.optString("banner"), description = o.optString("description"),
            year = o.optInt("year"), score = o.optInt("score"), episodes = o.optInt("episodes"),
            format = o.optString("format"), status = o.optString("status"),
            genres = o.optJSONArray("genres")?.let { a -> (0 until a.length()).map { a.optString(it) } } ?: emptyList()
        )
    }
}

data class StreamSource(val url: String, val label: String, val subtitleUrl: String = "") {
    fun toJson() = JSONObject().put("url", url).put("label", label).put("subtitle", subtitleUrl)
    companion object {
        fun fromJson(o: JSONObject) = StreamSource(o.optString("url"), o.optString("label"), o.optString("subtitle"))
    }
}

data class Watched(val anime: Anime, val source: StreamSource, val positionMs: Long) {
    fun toJson() = JSONObject().put("anime", anime.toJson()).put("source", source.toJson()).put("position", positionMs)
    companion object {
        fun fromJson(o: JSONObject) = Watched(
            Anime.fromJson(o.getJSONObject("anime")), StreamSource.fromJson(o.getJSONObject("source")), o.optLong("position")
        )
    }
}

data class OfflineItem(val anime: Anime, val label: String, val downloadId: Long) {
    fun toJson() = JSONObject().put("anime", anime.toJson()).put("label", label).put("downloadId", downloadId)
    companion object {
        fun fromJson(o: JSONObject) = OfflineItem(
            Anime.fromJson(o.getJSONObject("anime")), o.optString("label"), o.optLong("downloadId")
        )
    }
}

class AniListApi {
    private val client = OkHttpClient.Builder().callTimeout(20, TimeUnit.SECONDS).build()
    private val mediaQuery = """
        query (${'$'}page:Int, ${'$'}search:String, ${'$'}genre:String, ${'$'}year:Int,
               ${'$'}sort:[MediaSort], ${'$'}format:MediaFormat, ${'$'}status:MediaStatus) {
          Page(page:${'$'}page, perPage:24) {
            media(type:ANIME, isAdult:false, search:${'$'}search, genre:${'$'}genre,
                  seasonYear:${'$'}year, sort:${'$'}sort, format:${'$'}format, status:${'$'}status) {
              id title { english romaji } coverImage { extraLarge large } bannerImage
              description(asHtml:false) episodes seasonYear averageScore format status genres
            }
          }
        }
    """.trimIndent()

    fun browse(page: Int, search: String, genre: String, year: String, sort: String, format: String, status: String): List<Anime> {
        val variables = JSONObject().put("page", page).put("sort", JSONArray(listOf(sort)))
        if (search.isNotBlank()) variables.put("search", search.trim())
        if (genre.isNotBlank()) variables.put("genre", genre)
        if (year.toIntOrNull() != null) variables.put("year", year.toInt())
        if (format.isNotBlank()) variables.put("format", format)
        if (status.isNotBlank()) variables.put("status", status)
        val payload = JSONObject().put("query", mediaQuery).put("variables", variables)
        val request = Request.Builder().url("https://graphql.anilist.co")
            .post(payload.toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("AniList request failed (${response.code}). Try again later.")
            val root = JSONObject(response.body?.string() ?: "{}")
            if (root.has("errors")) error(root.optJSONArray("errors")?.optJSONObject(0)?.optString("message") ?: "Catalog API error")
            val arr = root.getJSONObject("data").getJSONObject("Page").getJSONArray("media")
            return (0 until arr.length()).map { idx ->
                val item = arr.getJSONObject(idx)
                val title = item.optJSONObject("title")
                val cover = item.optJSONObject("coverImage")
                val rawDescription = item.optString("description", "")
                Anime(
                    id = item.getInt("id"),
                    title = title?.optString("english")?.takeIf { it.isNotBlank() && it != "null" }
                        ?: title?.optString("romaji") ?: "Untitled",
                    image = cover?.optString("extraLarge")?.takeIf { it.isNotBlank() } ?: cover?.optString("large").orEmpty(),
                    banner = item.optString("bannerImage", "").takeUnless { it == "null" }.orEmpty(),
                    description = Html.fromHtml(rawDescription, Html.FROM_HTML_MODE_LEGACY).toString().trim(),
                    year = item.optInt("seasonYear"), score = item.optInt("averageScore"),
                    episodes = item.optInt("episodes"),
                    format = item.optString("format").takeUnless { it == "null" }.orEmpty(),
                    status = item.optString("status").takeUnless { it == "null" }.orEmpty(),
                    genres = item.optJSONArray("genres")?.let { a -> (0 until a.length()).map { a.getString(it) } } ?: emptyList()
                )
            }
        }
    }
}

/** Replace/add backends using a verified, licensed service implementation. */
interface EpisodeProvider {
    val id: String
    suspend fun episodes(anime: Anime): List<Episode>
}
data class Episode(val id: String, val name: String, val streams: List<StreamSource>)

class GoldenHenStore(context: Context) {
    private val prefs = context.getSharedPreferences("goldenhen_store", Context.MODE_PRIVATE)

    private fun getArray(key: String): JSONArray = runCatching { JSONArray(prefs.getString(key, "[]")) }.getOrDefault(JSONArray())
    private fun setArray(key: String, arr: JSONArray) { prefs.edit().putString(key, arr.toString()).apply() }

    fun saved(key: String): List<Anime> {
        val arr = getArray(key)
        return (0 until arr.length()).mapNotNull { runCatching { Anime.fromJson(arr.getJSONObject(it)) }.getOrNull() }
    }
    fun toggle(key: String, anime: Anime) {
        val old = saved(key)
        setArray(key, JSONArray(if (old.any { it.id == anime.id }) old.filterNot { it.id == anime.id }.map { it.toJson() }
                            else (old + anime).map { it.toJson() }))
    }
    fun history(): List<Watched> {
        val arr = getArray("history")
        return (0 until arr.length()).mapNotNull { runCatching { Watched.fromJson(arr.getJSONObject(it)) }.getOrNull() }
    }
    fun watched(animeId: Int): Watched? = history().firstOrNull { it.anime.id == animeId }
    fun record(anime: Anime, source: StreamSource, positionMs: Long) {
        val list = listOf(Watched(anime, source, positionMs)) + history().filterNot { it.anime.id == anime.id }
        setArray("history", JSONArray(list.take(80).map { it.toJson() }))
    }
    /** User-supplied, authorized episode sources saved on the device only. */
    fun episodes(animeId: Int): List<StreamSource> {
        val arr = getArray("episodes_$animeId")
        return (0 until arr.length()).mapNotNull { index ->
            runCatching { StreamSource.fromJson(arr.getJSONObject(index)) }.getOrNull()
        }
    }
    fun saveEpisode(animeId: Int, source: StreamSource) {
        require(source.url.startsWith("https://", true)) { "HTTPS playback URLs only." }
        val updated = episodes(animeId).filterNot { it.url == source.url || it.label.equals(source.label, true) } + source
        setArray("episodes_$animeId", JSONArray(updated.map { it.toJson() }))
    }
    fun removeEpisode(animeId: Int, url: String) {
        setArray("episodes_$animeId", JSONArray(episodes(animeId).filterNot { it.url == url }.map { it.toJson() }))
    }
    fun nextEpisode(animeId: Int, currentUrl: String): StreamSource? {
        val items = episodes(animeId)
        val index = items.indexOfFirst { it.url == currentUrl }
        return if (index >= 0) items.getOrNull(index + 1) else null
    }
    fun downloads(): List<OfflineItem> {
        val arr = getArray("downloads")
        return (0 until arr.length()).mapNotNull { runCatching { OfflineItem.fromJson(arr.getJSONObject(it)) }.getOrNull() }
    }
    fun recordDownload(item: OfflineItem) {
        setArray("downloads", JSONArray((listOf(item) + downloads()).map { it.toJson() }))
    }
    fun download(context: Context, anime: Anime, source: StreamSource): Result<Long> = runCatching {
        val uri = Uri.parse(source.url)
        require(uri.scheme == "https") { "Only HTTPS direct video downloads are supported." }
        require(uri.path?.endsWith(".mp4", ignoreCase = true) == true) {
            "Offline downloads currently support direct MP4 links only, not HLS/DASH or DRM streams."
        }
        val filename = "GoldenHen_${anime.id}_${System.currentTimeMillis()}.mp4"
        val request = DownloadManager.Request(uri)
            .setTitle("${anime.title} — ${source.label}")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setMimeType("video/mp4")
            .setDestinationInExternalFilesDir(context, Environment.DIRECTORY_MOVIES, filename)
        val manager = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val id = manager.enqueue(request)
        recordDownload(OfflineItem(anime, source.label, id))
        id
    }
    fun offlineStatus(context: Context, item: OfflineItem): Pair<Int, String?> {
        val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        val cursor = dm.query(DownloadManager.Query().setFilterById(item.downloadId)) ?: return -1 to null
        cursor.use {
            if (!it.moveToFirst()) return -1 to null
            val status = it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
            val uri = if (status == DownloadManager.STATUS_SUCCESSFUL) dm.getUriForDownloadedFile(item.downloadId)?.toString() else null
            return status to uri
        }
    }
}
