package com.goldenhen.anime

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

/** User-confirmed website domains. We NEVER infer replacement domains from a failed link. */
internal object AnimeSiteDomains {
    val hosts = listOf("animepahe.ng", "animepahe.ch")
    fun url(host: String): String = "https://$host/"
}

private val probeClient = OkHttpClient.Builder()
    .followRedirects(false)
    .followSslRedirects(false)
    .callTimeout(12, TimeUnit.SECONDS)
    .build()

/** A 403 often means bot protection; it is NOT proof that the website is offline. */
private suspend fun checkDomain(host: String): String = withContext(Dispatchers.IO) {
    try {
        val request = Request.Builder().url(AnimeSiteDomains.url(host))
            .header("User-Agent", "Mozilla/5.0 (Android; Golden Hen Site Check)")
            .get().build()
        probeClient.newCall(request).execute().use { response ->
            val destination = response.header("Location")
            if (response.code in 300..399 && destination != null) {
                val redirectHost = Uri.parse(destination).host ?: host
                if (redirectHost != host && redirectHost != "www.$host")
                    "Redirect detected to $redirectHost — verify before changing domains"
                else "Website redirected (HTTP ${response.code})"
            } else when (response.code) {
                in 200..299 -> "Website responded (HTTP ${response.code})"
                401, 403, 429 -> "Website responded with access protection (HTTP ${response.code})"
                in 500..599 -> "Website/server error (HTTP ${response.code})"
                else -> "Website responded (HTTP ${response.code})"
            }
        }
    } catch (e: Exception) {
        "Could not check this domain — ${e.javaClass.simpleName}"
    }
}

private class GoldenSiteChromeClient(private val activity: Activity?) : WebChromeClient() {
    private var fullscreenView: View? = null
    private var fullscreenCallback: CustomViewCallback? = null
    override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
        if (view == null || activity == null || fullscreenView != null) {
            callback?.onCustomViewHidden()
            return
        }
        fullscreenView = view
        fullscreenCallback = callback
        val root = activity.window.decorView as? ViewGroup
        root?.addView(view, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        activity.window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }
    override fun onHideCustomView() {
        val root = activity?.window?.decorView as? ViewGroup
        fullscreenView?.let { root?.removeView(it) }
        fullscreenView = null
        fullscreenCallback?.onCustomViewHidden()
        fullscreenCallback = null
        activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }
    fun close() = onHideCustomView()
}

/**
 * The website displays its OWN live index and released episodes. Native AniList categories
 * are a separate metadata index and must not be described as a mirror of this site's catalog.
 * Website video uses the website player, not the standalone Media3 player.
 */
@Composable
fun AnimeSiteScreen(searchHint: String) {
    val context = LocalContext.current
    val activity = context as? Activity
    val prefs = remember { context.getSharedPreferences("goldenhen_site", Context.MODE_PRIVATE) }
    var host by remember { mutableStateOf(prefs.getString("host", AnimeSiteDomains.hosts.first())!!.takeIf { it in AnimeSiteDomains.hosts } ?: AnimeSiteDomains.hosts.first()) }
    var status by remember(host) { mutableStateOf("Checking website…") }
    var checkCounter by remember { mutableIntStateOf(0) }
    var hasHistory by remember { mutableStateOf(false) }
    var pageError by remember { mutableStateOf<String?>(null) }
    val chrome = remember(activity) { GoldenSiteChromeClient(activity) }
    val webView = remember(context) {
        WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            settings.setSupportMultipleWindows(false)
            if (Build.VERSION.SDK_INT >= 26) settings.safeBrowsingEnabled = true
            webChromeClient = chrome
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val uri = request?.url ?: return false
                    if (uri.scheme == "https" &&
                        (uri.host in AnimeSiteDomains.hosts || uri.host?.removePrefix("www.") in AnimeSiteDomains.hosts)) {
                        return false
                    }
                    // Off-site links must open visibly in the system browser instead of silently
                    // navigating to unverified mirrors or ad-gateways inside the app.
                    if (uri.scheme == "https" || uri.scheme == "http") {
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                    }
                    return true
                }
                override fun onPageFinished(view: WebView?, url: String?) {
                    hasHistory = view?.canGoBack() == true
                    pageError = null
                }
                override fun onReceivedError(
                    view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?
                ) {
                    if (request?.isForMainFrame == true) pageError = "Website unavailable in embedded view. Try Open in browser."
                }
            }
        }
    }
    DisposableEffect(webView) {
        onDispose {
            chrome.close()
            webView.stopLoading()
            webView.loadUrl("about:blank")
            webView.destroy()
        }
    }
    LaunchedEffect(host) { webView.loadUrl(AnimeSiteDomains.url(host)) }
    LaunchedEffect(host, checkCounter) { status = checkDomain(host) }
    BackHandler(enabled = hasHistory) {
        if (webView.canGoBack()) webView.goBack()
        hasHistory = webView.canGoBack()
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 13.dp)) {
        Text("Anime website", fontWeight = FontWeight.Bold, fontSize = 22.sp)
        Text("Live website catalog and episode pages", color = Color(0xFFACA6BA), fontSize = 12.sp)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AnimeSiteDomains.hosts.forEach { candidate ->
                FilterChip(selected = host == candidate, onClick = {
                    host = candidate
                    prefs.edit().putString("host", host).apply()
                    hasHistory = false
                    pageError = null
                }, label = { Text(candidate, fontSize = 11.sp) })
            }
        }
        Text(status, color = Color(0xFFFFCB58), fontSize = 11.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { checkCounter++ }) {
                Icon(Icons.Filled.Refresh, null, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(4.dp))
                Text("Check domain")
            }
            TextButton(onClick = {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(AnimeSiteDomains.url(host))))
            }) {
                Icon(Icons.Filled.OpenInBrowser, null, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(4.dp))
                Text("Open in browser")
            }
        }
        if (searchHint.isNotBlank()) {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF25202B)),
                shape = RoundedCornerShape(12.dp)) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Find: $searchHint", Modifier.weight(1f), maxLines = 2, fontSize = 12.sp)
                    TextButton(onClick = {
                        val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        manager.setPrimaryClip(ClipData.newPlainText("Anime title", searchHint))
                    }) { Text("Copy") }
                }
            }
        }
        if (pageError != null) Text(pageError!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        Spacer(Modifier.height(5.dp))
        AndroidView(factory = { webView }, modifier = Modifier.fillMaxWidth().weight(1f))
        Text("The website controls its episode availability and video playback. Golden Hen does not copy or host its videos.",
            color = Color(0xFFACA6BA), fontSize = 10.sp, modifier = Modifier.padding(vertical = 5.dp))
    }
}
