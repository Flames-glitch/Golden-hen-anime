# Golden Hen — Anime app v0.2

Dark-and-gold Android mobile anime discovery app and a custom **Aurora Media Android–style** video player. Kotlin, Jetpack Compose, Media3 (ExoPlayer), AniList metadata. Runs without an account.

## What's included in V2

- Anime discovery, search, paging, watchlists, favorites, watch history, and continue watching (from V1).
- A separate full-screen custom Android **Media3 player** with centered Play/Pause, −10s and +10s buttons, lower seek bar, and tap to show/hide controls.
- Double-tap left/right for ±10s, horizontal swipe to seek, vertical swipe on left to adjust brightness / right to adjust volume, pinch to toggle Fit/Zoom-to-Fill.
- Automatic portrait-to-landscape playback and keep-screen-awake; return to previous orientation and brightness when closing.
- Playback speed 0.5–2x, subtitle text size, adaptive video resolution caps (Auto / 720p / 1080p / 4K). Actual qualities depend on the media playlist/codec/device.
- Audio and subtitle track selector for tracks **actually present in the provided stream**; supports an optional external HTTPS SRT/WebVTT file.
- Picture-in-picture on compatible Android 8+ devices; pause playback when no longer foreground or in PiP; release the player on exit.
- Save your **own authorized** HTTPS video URLs as per-title episode queues. Next Episode button and 3-second automatic next episode after ending, when another queue item exists.
- Buffering spinner, error + retry, Resume (last title/URL), and Start Again from the player.
- V1 direct HTTPS MP4 download manager and offline library remain available.

## How to update the existing GitHub project

**Reuse the original `.github/workflows/build-apk.yml`.** It is unchanged from V1, already uses `actions/setup-java@v5`, `gradle/actions/setup-gradle@v4`, Gradle 8.11.1 and JDK 17. No extra YAML, repository or secrets are needed.

1. Download the v0.2 ZIP and **extract it**.
2. Open the `GoldenHen_Android_Repo_v0.2` folder inside the ZIP.
3. Upload the **contents of that folder**, including hidden `.github/`, to your existing Golden Hen GitHub repository, replacing V1 project files. Do **not** leave the old V1 `GoldenHenPlayer.kt` alongside the V2 version.
4. Go to **Actions → Build Golden Hen APK → Run workflow** (or push to the `main` branch).
5. When Actions succeeds, download `GoldenHen-debug-apk` and install the debug APK. If it fails, share the full Actions error log.

`app/build.gradle.kts` now uses `versionCode = 2` and `versionName = "0.2.0"`.

## Content and streaming limitations

- Anime entries and cover images come from AniList metadata. **This is not a licensed anime streaming service**; AniList does not provide episode video.
- There is **no automatic Animepahe-api integration**: the source and license of that external project have not been inspected. Only paste/watch links you're authorized to use.
- Episodes are saved by you, on-device, in the order added. The player can advance to a next saved source; it cannot discover anime episode URLs automatically.
- Video quality selection is a **maximum height/resolution cap**, not an ability to create a stream quality missing from the source. Not all video containers/codecs/devices can handle 4K. Software decoder fallback is not provided in V2.
- PiP uses standard Android APIs and may depend on device/launcher. Multi-audio and subtitle options only appear where the stream offers those tracks.
- Supported downloadable videos remain **direct HTTPS .mp4 only** (no DRM circumvention, HLS download, or offline license handling).
- Skip-intro/outro is not provided because no trusted per-episode timestamps are available.

## Testing status

This source package has **not** been compiled or tested on an Android device in this environment (Android SDK/Gradle installation unavailable). The GitHub Actions build is therefore the actual build check. Share a failing log for corrections rather than assuming a successful APK.

## Architecture

- `MainActivity.kt` — Compose browsing, detail and on-device episode queue UI.
- `AnimeData.kt` — AniList GraphQL metadata client, JSON SharedPreferences, local user playlists, download manager.
- `GoldenHenPlayer.kt` — player lifecycle, Media3 controls, gesture UI, PiP, quality caps, subtitles and audio track selector.
- `.github/workflows/build-apk.yml` — existing unchanged GitHub build workflow.

No APK, anime episodes, copyrighted anime assets, unauthorized streaming providers, scraping automation, secret keys, or access-controlled URLs are bundled.
