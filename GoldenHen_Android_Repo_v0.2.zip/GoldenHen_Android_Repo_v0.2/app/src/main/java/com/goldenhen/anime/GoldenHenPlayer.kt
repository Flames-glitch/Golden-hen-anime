package com.goldenhen.anime

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.util.Rational
import android.util.TypedValue
import android.view.WindowManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.roundToInt

private val PlayerGold = Color(0xFFFFCB58)
private val PlayerPanel = Color(0xE51B1822)

private fun clock(ms: Long): String {
    val sec = (ms.coerceAtLeast(0) / 1000)
    return if (sec >= 3600) "%d:%02d:%02d".format(sec / 3600, (sec / 60) % 60, sec % 60)
    else "%02d:%02d".format(sec / 60, sec % 60)
}

private fun trackTitle(group: Tracks.Group, index: Int): String {
    val format = group.getTrackFormat(index)
    val locale = format.language?.takeUnless { it == "und" }.orEmpty()
    val title = format.label?.takeIf { it.isNotBlank() } ?: locale.ifBlank { "Track ${index + 1}" }
    return if (format.label != null && locale.isNotBlank()) "$title ($locale)" else title
}

private data class PlaybackTrack(val group: Tracks.Group, val index: Int, val title: String, val selected: Boolean)

/**
 * Golden Hen v0.2: Aurora Media phone-style playback UI, built from Media3.
 * Source URLs must be provided by the user or an authorized provider.
 * PlayerView's native controller is disabled so the touch UI remains consistent.
 */
@Composable
fun GoldenHenPlayerScreen(
    anime: Anime,
    source: StreamSource,
    offline: Boolean,
    store: GoldenHenStore,
    onNext: (StreamSource) -> Unit,
    onExit: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val lifecycleOwner = LocalLifecycleOwner.current
    val audioManager = remember(context) { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val maxVolume = remember(audioManager) { audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1) }
    val volumeState = remember { mutableFloatStateOf(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) / maxVolume.toFloat()) }
    val brightnessState = remember { mutableFloatStateOf(activity?.window?.attributes?.screenBrightness?.takeIf { it >= 0f } ?: .65f) }

    var showControls by remember { mutableStateOf(true) }
    var isPlaying by remember { mutableStateOf(false) }
    var buffering by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var isFinished by remember { mutableStateOf(false) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var isFill by remember { mutableStateOf(false) }
    var speed by remember { mutableFloatStateOf(1f) }
    var subtitleFont by remember { mutableFloatStateOf(19f) }
    var showSettings by remember { mutableStateOf(false) }
    var showTracks by remember { mutableStateOf(false) }
    var selectedTrackTab by remember { mutableIntStateOf(C.TRACK_TYPE_AUDIO) }
    var trackRefresh by remember { mutableIntStateOf(0) }
    var hint by remember { mutableStateOf<String?>(null) }
    var quality by remember { mutableStateOf("Auto") }
    val nextSource = remember(anime.id, source.url) { if (offline) null else store.nextEpisode(anime.id, source.url) }

    val player = remember(anime.id, source.url) {
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(12_000, 50_000, 1_500, 3_000)
            .build()
        ExoPlayer.Builder(context).setLoadControl(loadControl).build().apply {
            val item = MediaItem.Builder().setUri(Uri.parse(source.url))
            if (source.subtitleUrl.startsWith("https://", true)) {
                val mime = if (source.subtitleUrl.substringBefore('?').endsWith(".srt", true))
                    MimeTypes.APPLICATION_SUBRIP else MimeTypes.TEXT_VTT
                item.setSubtitleConfigurations(listOf(
                    MediaItem.SubtitleConfiguration.Builder(Uri.parse(source.subtitleUrl))
                        .setMimeType(mime).setLanguage("en").setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()
                ))
            }
            setMediaItem(item.build())
            if (!offline) {
                store.watched(anime.id)?.takeIf { it.source.url == source.url && it.positionMs > 0 }?.let {
                    seekTo(it.positionMs)
                }
            }
            playWhenReady = true
            prepare()
        }
    }

    DisposableEffect(player, lifecycleOwner) {
        val oldOrientation = activity?.requestedOrientation
        val oldBrightness = activity?.window?.attributes?.screenBrightness
        val oldKeepAwake = ((activity?.window?.attributes?.flags ?: 0) and WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) != 0
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        activity?.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    if (!offline) store.record(anime, source, player.currentPosition.coerceAtLeast(0L))
                    // Keep streaming in PiP; ON_STOP pauses if actually backgrounded.
                }
                Lifecycle.Event.ON_STOP -> {
                    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || activity?.isInPictureInPictureMode != true) player.pause()
                }
                Lifecycle.Event.ON_RESUME -> {
                    // Do not resume automatically after returning from an unrelated background app.
                    showControls = true
                }
                else -> Unit
            }
        }
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onPlaybackStateChanged(state: Int) {
                buffering = state == Player.STATE_BUFFERING
                isFinished = state == Player.STATE_ENDED
                if (state == Player.STATE_ENDED && !offline) store.record(anime, source, 0L)
            }
            override fun onTracksChanged(tracks: Tracks) { trackRefresh++ }
            override fun onPlayerError(problem: PlaybackException) {
                error = problem.localizedMessage ?: "Unable to play this source."
                buffering = false
                showControls = true
            }
        }
        player.addListener(listener)
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            if (!offline && !isFinished) store.record(anime, source, player.currentPosition.coerceAtLeast(0L))
            lifecycleOwner.lifecycle.removeObserver(observer)
            player.removeListener(listener)
            player.pause()
            player.release()
            oldOrientation?.let { activity.requestedOrientation = it }
            if (activity != null && oldBrightness != null) {
                activity.window.attributes = activity.window.attributes.apply { screenBrightness = oldBrightness }
            }
            if (!oldKeepAwake) activity?.window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    LaunchedEffect(player) {
        while (true) {
            position = player.currentPosition.coerceAtLeast(0L)
            duration = if (player.duration > 0L && player.duration != C.TIME_UNSET) player.duration else 0L
            delay(400)
        }
    }
    LaunchedEffect(showControls, isPlaying, showSettings, showTracks) {
        if (showControls && isPlaying && !showSettings && !showTracks) {
            delay(5500)
            showControls = false
        }
    }
    LaunchedEffect(isFinished, nextSource) {
        if (isFinished && nextSource != null) {
            delay(3000) // Keep the on-screen Next control available before automatically advancing.
            onNext(nextSource)
        }
    }
    LaunchedEffect(hint) {
        if (hint != null) { delay(1000); hint = null }
    }

    fun seekRelative(deltaMs: Long) {
        val end = duration.takeIf { it > 0 } ?: Long.MAX_VALUE
        player.seekTo((player.currentPosition + deltaMs).coerceIn(0L, end))
        position = player.currentPosition.coerceAtLeast(0L)
        hint = if (deltaMs < 0) "−10 sec" else "+10 sec"
    }

    BackHandler(enabled = true) {
        when {
            showTracks -> showTracks = false
            showSettings -> showSettings = false
            else -> onExit()
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { viewContext -> PlayerView(viewContext).apply {
                useController = false
                this.player = player
                resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                setShutterBackgroundColor(android.graphics.Color.BLACK)
                subtitleView?.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, subtitleFont)
            } },
            update = { view ->
                view.player = player
                view.resizeMode = if (isFill) AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT
                view.subtitleView?.setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, subtitleFont)
            },
            modifier = Modifier.fillMaxSize()
        )

        // Invisible touch layer: one tap = controls; double tap sides = 10s; horizontal/vertical swipes.
        var dragDirection by remember { mutableIntStateOf(0) }
        var dragAccumulated by remember { mutableFloatStateOf(0f) }
        var startingPosition by remember { mutableLongStateOf(0L) }
        var startingVolume by remember { mutableFloatStateOf(0f) }
        var startingBrightness by remember { mutableFloatStateOf(0f) }
        var leftGesture by remember { mutableStateOf(false) }
        Box(
            Modifier.fillMaxSize()
                .pointerInput(player) {
                    detectTapGestures(
                        onTap = { showControls = !showControls },
                        onDoubleTap = { tap ->
                            if (tap.x < size.width * 0.45f) seekRelative(-10_000L)
                            else if (tap.x > size.width * 0.55f) seekRelative(10_000L)
                            else { if (player.isPlaying) player.pause() else player.play(); showControls = true }
                        }
                    )
                }
                .pointerInput(player) {
                    detectDragGestures(
                        onDragStart = { start: Offset ->
                            dragDirection = 0; dragAccumulated = 0f
                            startingPosition = player.currentPosition
                            startingVolume = volumeState.floatValue
                            startingBrightness = brightnessState.floatValue
                            leftGesture = start.x < size.width / 2f
                        },
                        onDragEnd = { dragDirection = 0; dragAccumulated = 0f },
                        onDragCancel = { dragDirection = 0; dragAccumulated = 0f },
                        onDrag = { change, amount ->
                            if (dragDirection == 0) dragDirection = if (abs(amount.x) > abs(amount.y)) 1 else 2
                            val distance = if (dragDirection == 1) amount.x else amount.y
                            dragAccumulated += distance
                            if (dragDirection == 1 && duration > 0L) {
                                val delta = ((dragAccumulated / size.width) * duration.toDouble() * 0.75).toLong()
                                val target = (startingPosition + delta).coerceIn(0L, duration)
                                player.seekTo(target)
                                position = target
                                hint = "Seek ${clock(target)}"
                            } else if (dragDirection == 2) {
                                val difference = -dragAccumulated / size.height.toFloat()
                                if (leftGesture) {
                                    val next = (startingBrightness + difference).coerceIn(.02f, 1f)
                                    brightnessState.floatValue = next
                                    activity?.window?.attributes = activity.window.attributes.apply { screenBrightness = next }
                                    hint = "Brightness ${(next * 100).roundToInt()}%"
                                } else {
                                    val next = (startingVolume + difference).coerceIn(0f, 1f)
                                    volumeState.floatValue = next
                                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, (next * maxVolume).roundToInt(), 0)
                                    hint = "Volume ${(next * 100).roundToInt()}%"
                                }
                            }
                            change.consume()
                        }
                    )
                }
                .pointerInput(player) {
                    detectTransformGestures { _, _, zoom, _ ->
                        if (zoom > 1.04f) { isFill = true; hint = "Zoom to fill" }
                        else if (zoom < .96f) { isFill = false; hint = "Fit to screen" }
                    }
                }
        )

        if (buffering && error == null) CircularProgressIndicator(color = PlayerGold, modifier = Modifier.align(Alignment.Center))
        if (hint != null) {
            Text(hint.orEmpty(), color = Color.White, fontSize = 15.sp,
                modifier = Modifier.align(Alignment.Center).background(PlayerPanel, RoundedCornerShape(12.dp)).padding(14.dp))
        }
        if (error != null) {
            Column(Modifier.align(Alignment.Center).background(PlayerPanel, RoundedCornerShape(16.dp)).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Playback error", color = PlayerGold, fontWeight = FontWeight.Bold)
                Text(error.orEmpty(), color = Color.White, fontSize = 12.sp)
                Button(onClick = { error = null; player.prepare(); player.play() }) { Text("Retry") }
            }
        }

        if (showControls) {
            Row(
                Modifier.fillMaxWidth().align(Alignment.TopCenter).background(PlayerPanel).padding(horizontal = 5.dp, vertical = 3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onExit) { Icon(Icons.Filled.ArrowBack, "Exit player", tint = PlayerGold) }
                Column(Modifier.weight(1f)) {
                    Text(anime.title, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(source.label, color = PlayerGold, fontSize = 11.sp, maxLines = 1)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && activity != null) {
                    IconButton(onClick = {
                        runCatching {
                            activity.enterPictureInPictureMode(
                                PictureInPictureParams.Builder().setAspectRatio(Rational(16, 9)).build()
                            )
                        }.onFailure { hint = "PiP not available on this device" }
                    }) { Icon(Icons.Filled.PictureInPictureAlt, "Picture in picture", tint = Color.White) }
                }
                IconButton(onClick = { isFill = !isFill; hint = if (isFill) "Zoom to fill" else "Fit to screen" }) {
                    Icon(Icons.Filled.AspectRatio, "Fit or fill", tint = Color.White)
                }
                IconButton(onClick = { showSettings = true; showControls = true }) {
                    Icon(Icons.Filled.Settings, "Playback settings", tint = Color.White)
                }
            }
            Row(
                Modifier.align(Alignment.Center).padding(top = 22.dp),
                horizontalArrangement = Arrangement.spacedBy(25.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { seekRelative(-10_000L) }, modifier = Modifier.size(55.dp)) {
                    Icon(Icons.Filled.Replay10, "Back ten seconds", tint = Color.White, modifier = Modifier.size(40.dp))
                }
                FilledIconButton(onClick = { if (player.isPlaying) player.pause() else {
                    if (isFinished) player.seekTo(0L)
                    player.play()
                } }, modifier = Modifier.size(64.dp), colors = IconButtonDefaults.filledIconButtonColors(containerColor = PlayerGold, contentColor = Color.Black)) {
                    Icon(if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, if (isPlaying) "Pause" else "Play", modifier = Modifier.size(41.dp))
                }
                IconButton(onClick = { seekRelative(10_000L) }, modifier = Modifier.size(55.dp)) {
                    Icon(Icons.Filled.Forward10, "Forward ten seconds", tint = Color.White, modifier = Modifier.size(40.dp))
                }
            }
            Column(
                Modifier.fillMaxWidth().align(Alignment.BottomCenter).background(PlayerPanel)
                    .padding(horizontal = 15.dp, vertical = 5.dp)
            ) {
                Slider(
                    value = if (duration > 0L) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f,
                    onValueChange = { fraction ->
                        if (duration > 0) { val target = (fraction * duration).toLong(); position = target; player.seekTo(target) }
                    },
                    enabled = duration > 0L,
                    colors = SliderDefaults.colors(thumbColor = PlayerGold, activeTrackColor = PlayerGold),
                    modifier = Modifier.fillMaxWidth().height(32.dp)
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${clock(position)} / ${clock(duration)}", color = Color.White, fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { player.seekTo(0L); player.play(); hint = "Playing from beginning" }) {
                        Icon(Icons.Filled.RestartAlt, null, tint = PlayerGold, modifier = Modifier.size(17.dp))
                        Text("Start again", color = PlayerGold, fontSize = 11.sp)
                    }
                    if (nextSource != null) {
                        TextButton(onClick = { onNext(nextSource) }) {
                            Icon(Icons.Filled.SkipNext, null, tint = PlayerGold, modifier = Modifier.size(17.dp))
                            Text("Next episode", color = PlayerGold, fontSize = 11.sp)
                        }
                    }
                    TextButton(onClick = { selectedTrackTab = C.TRACK_TYPE_AUDIO; showTracks = true }) {
                        Icon(Icons.Filled.Subtitles, null, tint = PlayerGold, modifier = Modifier.size(17.dp))
                        Text("Audio & Subs", color = PlayerGold, fontSize = 11.sp)
                    }
                }
            }
        }
    }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("Player settings") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Playback speed: ${"%.2f".format(speed)}×")
                    Slider(value = speed, onValueChange = { speed = it; player.setPlaybackSpeed(it) }, valueRange = .5f..2f, steps = 5)
                    Text("Subtitle size: ${subtitleFont.roundToInt()} sp")
                    Slider(value = subtitleFont, onValueChange = { subtitleFont = it }, valueRange = 12f..34f)
                    Text("Maximum stream resolution (HLS/DASH; if available)")
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("Auto", "720p", "1080p", "4K").forEach { item ->
                            FilterChip(selected = quality == item, onClick = {
                                quality = item
                                val bounds = when (item) {
                                    "720p" -> 1280 to 720
                                    "1080p" -> 1920 to 1080
                                    "4K" -> 3840 to 2160
                                    else -> Int.MAX_VALUE to Int.MAX_VALUE
                                }
                                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                                    .setMaxVideoSize(bounds.first, bounds.second).build()
                            }, label = { Text(item, fontSize = 11.sp) })
                        }
                    }
                    Text("Video is ${if (isFill) "zoomed to fill" else "fit to screen"}. Pinch to change.", fontSize = 12.sp)
                    Text("Use the left side to swipe brightness; right side for volume; swipe horizontally to seek.", fontSize = 11.sp)
                }
            },
            confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Done") } }
        )
    }

    if (showTracks) {
        val type = selectedTrackTab
        val tracks = remember(trackRefresh, type) {
            player.currentTracks.groups.filter { it.type == type }.flatMap { group ->
                (0 until group.length).filter { group.isTrackSupported(it) }.map { idx ->
                    PlaybackTrack(group, idx, trackTitle(group, idx), group.isTrackSelected(idx))
                }
            }
        }
        AlertDialog(
            onDismissRequest = { showTracks = false },
            title = { Text("Audio & subtitles") },
            text = {
                Column {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = type == C.TRACK_TYPE_AUDIO, onClick = { selectedTrackTab = C.TRACK_TYPE_AUDIO }, label = { Text("Audio") })
                        FilterChip(selected = type == C.TRACK_TYPE_TEXT, onClick = { selectedTrackTab = C.TRACK_TYPE_TEXT }, label = { Text("Subtitles") })
                    }
                    Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
                        if (type == C.TRACK_TYPE_TEXT) {
                            Row(Modifier.fillMaxWidth().clickable {
                                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                                    .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()
                                trackRefresh++
                            }.padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT), onClick = null)
                                Text("Off")
                            }
                        } else {
                            Row(Modifier.fillMaxWidth().clickable {
                                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                                    .clearOverridesOfType(C.TRACK_TYPE_AUDIO).build()
                                trackRefresh++
                            }.padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = player.trackSelectionParameters.overrides.isEmpty(), onClick = null)
                                Text("Auto / original")
                            }
                        }
                        tracks.forEach { track ->
                            Row(Modifier.fillMaxWidth().clickable {
                                player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
                                    .setTrackTypeDisabled(type, false)
                                    .setOverrideForType(TrackSelectionOverride(track.group.mediaTrackGroup, listOf(track.index)))
                                    .build()
                                trackRefresh++
                            }.padding(9.dp), verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = track.selected, onClick = null)
                                Text(track.title, fontSize = 14.sp)
                            }
                        }
                        if (tracks.isEmpty()) Text("No selectable tracks in this source.", fontSize = 12.sp)
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showTracks = false }) { Text("Done") } }
        )
    }
}
