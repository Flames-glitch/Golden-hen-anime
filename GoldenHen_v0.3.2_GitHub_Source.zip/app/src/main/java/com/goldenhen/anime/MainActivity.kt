package com.goldenhen.anime

import android.app.Activity
import android.app.DownloadManager
import android.content.Context
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.foundation.Image
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private val Gold = Color(0xFFFFCB58)
private val Ink = Color(0xFF0D0B12)
private val Surface = Color(0xFF1B1822)
private val Muted = Color(0xFFAEA8BC)

private val goldenColors = darkColorScheme(
    primary = Gold, onPrimary = Ink, secondary = Color(0xFFE5B74F),
    background = Ink, surface = Surface, onSurface = Color(0xFFF6F2FA),
    onBackground = Color(0xFFF6F2FA), surfaceVariant = Color(0xFF292533)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        setContent {
            MaterialTheme(colorScheme = goldenColors) {
                var acknowledged by remember { mutableStateOf(false) }
                val previousCrash = remember { CrashDiagnostics.lastCrash(applicationContext) }
                if (previousCrash != null && !acknowledged) {
                    CrashRecoveryScreen(onLaunch = { acknowledged = true })
                } else {
                    GoldenHenApp()
                }
            }
        }
    }
}

private data class Playback(val anime: Anime, val source: StreamSource, val offline: Boolean = false)

@Composable
private fun GoldenHenApp() {
    val context = LocalContext.current
    val store = remember { GoldenHenStore(context) }
    val api = remember { AniListApi() }
    var tab by rememberSaveable { mutableStateOf("Discover") }
    var detail by remember { mutableStateOf<Anime?>(null) }
    var playback by remember { mutableStateOf<Playback?>(null) }
    var savedVersion by remember { mutableIntStateOf(0) }
    var siteSearchHint by rememberSaveable { mutableStateOf("") }

    if (playback != null) {
        val current = playback!!
        GoldenHenPlayerScreen(
            anime = current.anime, source = current.source, offline = current.offline, store = store,
            onNext = { next -> playback = Playback(current.anime, next) },
            onExit = { playback = null; savedVersion++ }
        )
        return
    }
    if (detail != null) {
        DetailScreen(
            anime = detail!!, store = store,
            onBack = { detail = null },
            onPlay = { source -> playback = Playback(detail!!, source) },
            onSaved = { savedVersion++ },
            onDownloads = { tab = "Offline"; detail = null },
            onOpenSite = { title -> siteSearchHint = title; tab = "Animepahe"; detail = null }
        )
        return
    }

    val destinations = listOf("Discover", "Search", "My List", "Offline", "Animepahe")
    Scaffold(
        containerColor = Ink,
        topBar = {
            Row(
                modifier = Modifier.fillMaxWidth().background(Ink).padding(start = 18.dp, end = 18.dp, top = 16.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Image(painter = painterResource(id = R.mipmap.ic_launcher), contentDescription = "Golden Hen rooster logo", modifier = Modifier.size(34.dp))
                Spacer(Modifier.width(9.dp))
                Text("GOLDEN HEN", fontWeight = FontWeight.Black, fontSize = 23.sp, color = Gold, letterSpacing = 1.4.sp)
                Spacer(Modifier.weight(1f))
                Text("v0.3.2", style = MaterialTheme.typography.labelSmall, color = Muted)
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Surface) {
                destinations.forEach { destination ->
                    NavigationBarItem(
                        selected = tab == destination, onClick = { tab = destination },
                        icon = {
                            Icon(when (destination) {
                                "Discover" -> Icons.Filled.Home
                                "Search" -> Icons.Filled.Search
                                "My List" -> Icons.Filled.Bookmarks
                                "Offline" -> Icons.Filled.Download
                                else -> Icons.Filled.Language
                            }, null)
                        }, label = { Text(destination) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Ink, selectedTextColor = Gold, indicatorColor = Gold, unselectedIconColor = Muted, unselectedTextColor = Muted)
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                "Discover", "Search" -> BrowseScreen(
                    api = api, isSearch = tab == "Search", store = store, version = savedVersion,
                    onSelect = { detail = it }, onContinue = { playback = Playback(it.anime, it.source) }
                )
                "My List" -> SavedScreen(store, savedVersion, onSelect = { detail = it }, onContinue = { playback = Playback(it.anime, it.source) })
                "Offline" -> OfflineScreen(store, savedVersion, onSelect = { anime, url, label -> playback = Playback(anime, StreamSource(url, label), true) })
                else -> AnimeSiteScreen(siteSearchHint)
            }
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String? = null) {
    Column(Modifier.padding(vertical = 12.dp)) {
        Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        if (subtitle != null) Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun PosterCard(anime: Anime, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Card(shape = RoundedCornerShape(13.dp), colors = CardDefaults.cardColors(containerColor = Surface)) {
            Box {
                AsyncImage(
                    model = anime.image, contentDescription = "Poster for ${anime.title}",
                    modifier = Modifier.fillMaxWidth().aspectRatio(0.69f), contentScale = ContentScale.Crop
                )
                if (anime.score > 0) {
                    Text("★ ${anime.score}%", color = Ink, fontWeight = FontWeight.Bold, fontSize = 10.sp,
                        modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).background(Gold, RoundedCornerShape(6.dp)).padding(horizontal = 6.dp, vertical = 3.dp))
                }
            }
        }
        Text(anime.title, maxLines = 2, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold,
            fontSize = 13.sp, modifier = Modifier.padding(top = 7.dp))
        Text(listOfNotNull(anime.year.takeIf { it > 0 }?.toString(), anime.format.takeIf { it.isNotBlank() }).joinToString(" · "),
            color = Muted, fontSize = 11.sp, maxLines = 1)
    }
}

private val genreValues = listOf("" to "All genres", "Action" to "Action", "Adventure" to "Adventure", "Comedy" to "Comedy", "Drama" to "Drama", "Fantasy" to "Fantasy", "Horror" to "Horror", "Mystery" to "Mystery", "Romance" to "Romance", "Sci-Fi" to "Sci-Fi", "Slice of Life" to "Slice of Life", "Sports" to "Sports", "Supernatural" to "Supernatural")
private val formatValues = listOf("" to "All types", "TV" to "Series", "MOVIE" to "Movies", "OVA" to "OVA", "SPECIAL" to "Specials", "ONA" to "ONA")
private val statusValues = listOf("" to "All status", "RELEASING" to "Ongoing", "FINISHED" to "Completed", "NOT_YET_RELEASED" to "Upcoming")
private val sortValues = listOf("TRENDING_DESC" to "Trending", "POPULARITY_DESC" to "Popular", "SCORE_DESC" to "Top rated", "START_DATE_DESC" to "Recently aired")

@Composable
private fun FilterDrop(label: String, value: String, values: List<Pair<String, String>>, onChange: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }, contentPadding = PaddingValues(horizontal = 12.dp)) {
            Text("$label: ${values.firstOrNull { it.first == value }?.second ?: "All"}", maxLines = 1, fontSize = 11.sp)
            Spacer(Modifier.width(4.dp)); Icon(Icons.Filled.ArrowDropDown, null, modifier = Modifier.size(16.dp))
        }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            values.forEach { (key, title) ->
                DropdownMenuItem(text = { Text(title) }, onClick = { onChange(key); expanded = false })
            }
        }
    }
}

@Composable
private fun BrowseScreen(
    api: AniListApi, isSearch: Boolean, store: GoldenHenStore, version: Int,
    onSelect: (Anime) -> Unit, onContinue: (Watched) -> Unit
) {
    var search by rememberSaveable { mutableStateOf("") }
    var quickGroup by rememberSaveable { mutableStateOf("All") }
    var genre by rememberSaveable { mutableStateOf("") }
    var year by rememberSaveable { mutableStateOf("") }
    var format by rememberSaveable { mutableStateOf("") }
    var status by rememberSaveable { mutableStateOf("") }
    var sort by rememberSaveable { mutableStateOf("TRENDING_DESC") }
    var page by remember { mutableIntStateOf(1) }
    var results by remember { mutableStateOf<List<Anime>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var exhausted by remember { mutableStateOf(false) }
    var refreshKey by remember { mutableIntStateOf(0) }
    val history = remember(version) { store.history().filter { it.positionMs > 0 }.take(8) }
    val query = if (isSearch) search else ""
    LaunchedEffect(quickGroup) {
        when (quickGroup) {
            "Airing" -> { format = ""; status = "RELEASING" }
            "Series" -> { format = "TV"; status = "" }
            "Movies" -> { format = "MOVIE"; status = "" }
            "OVAs" -> { format = "OVA"; status = "" }
            "Specials" -> { format = "SPECIAL"; status = "" }
            "ONAs" -> { format = "ONA"; status = "" }
            else -> { format = ""; status = "" }
        }
    }

    LaunchedEffect(query, genre, year, format, status, sort, isSearch) {
        page = 1
        results = emptyList()
        exhausted = false
    }
    LaunchedEffect(page, query, genre, year, format, status, sort, isSearch, refreshKey) {
        if (isSearch) delay(450)
        loading = true; error = null
        try {
            val fetched = withContext(Dispatchers.IO) { api.browse(page, query, genre, year, sort, format, status) }
            results = if (page == 1) fetched else (results + fetched).distinctBy { it.id }
            exhausted = fetched.size < 24
        } catch (e: Exception) { error = e.message ?: "Could not connect to AniList." }
        finally { loading = false }
    }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(145.dp), modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 28.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(19.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                SectionTitle(if (isSearch) "Find your next anime" else "Discover anime", "Series · Movies · OVAs · Specials")
                if (!isSearch) {
                    Row(
                        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("All", "Airing", "Series", "Movies", "OVAs", "Specials", "ONAs").forEach { group ->
                            FilterChip(selected = quickGroup == group, onClick = { quickGroup = group }, label = { Text(group) })
                        }
                    }
                    Text("AniList metadata categories. The Animepahe tab shows the website's own live episode pages.",
                        color = Muted, fontSize = 11.sp)
                }
                if (isSearch) {
                    OutlinedTextField(
                        value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Search anime titles...") }, singleLine = true,
                        leadingIcon = { Icon(Icons.Filled.Search, null) }
                    )
                    Spacer(Modifier.height(10.dp))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterDrop("Genre", genre, genreValues) { genre = it }
                    FilterDrop("Type", format, formatValues) { format = it }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterDrop("Sort", sort, sortValues) { sort = it }
                    FilterDrop("Status", status, statusValues) { status = it }
                }
                OutlinedTextField(value = year, onValueChange = { if (it.length <= 4 && it.all(Char::isDigit)) year = it },
                    label = { Text("Release year (optional)") }, modifier = Modifier.fillMaxWidth(),
                    singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                if (!isSearch && history.isNotEmpty()) {
                    SectionTitle("Continue watching")
                    history.forEach { entry ->
                        Row(Modifier.fillMaxWidth().clickable { onContinue(entry) }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(model = entry.anime.image, contentDescription = null,
                                modifier = Modifier.size(width = 48.dp, height = 68.dp), contentScale = ContentScale.Crop)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(entry.anime.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${entry.source.label} · ${entry.positionMs / 60000}m watched", color = Muted, fontSize = 12.sp)
                            }
                            Icon(Icons.Filled.PlayCircle, null, tint = Gold)
                        }
                    }
                }
                SectionTitle(if (isSearch) "Results" else "Trending now")
            }
        }
        items(results, key = { it.id }) { anime -> PosterCard(anime) { onSelect(anime) } }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                if (loading) CircularProgressIndicator(color = Gold)
                if (error != null) {
                    Text(error!!, color = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { page = 1; results = emptyList(); error = null; refreshKey++ }) { Text("Retry") }
                } else if (!loading && !exhausted) {
                    OutlinedButton(onClick = { page += 1 }) { Text("Load more anime") }
                } else if (!loading && results.isEmpty()) {
                    Text("No titles found. Try changing the filters.", color = Muted)
                }
            }
        }
    }
}

@Composable
private fun SavedScreen(store: GoldenHenStore, version: Int, onSelect: (Anime) -> Unit, onContinue: (Watched) -> Unit) {
    var subtab by rememberSaveable { mutableStateOf("Watchlist") }
    val saved = remember(version, subtab) { store.saved(if (subtab == "Favorites") "favorites" else "watchlist") }
    val history = remember(version) { store.history() }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        SectionTitle("My collection", "Stored on this device. No account required.")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Watchlist", "Favorites", "History").forEach { name ->
                FilterChip(selected = subtab == name, onClick = { subtab = name }, label = { Text(name) })
            }
        }
        if (subtab == "History") {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(history, key = { it.anime.id }) { entry ->
                    AnimeListRow(entry.anime, "${entry.source.label} · ${entry.positionMs / 60000}m") { onContinue(entry) }
                }
                if (history.isEmpty()) item { Text("Your watch history will appear here.", color = Muted) }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(saved, key = { it.id }) { anime -> AnimeListRow(anime, anime.genres.take(2).joinToString(" · ")) { onSelect(anime) } }
                if (saved.isEmpty()) item { Text("No anime saved here yet. Open a title to add it.", color = Muted) }
            }
        }
    }
}

@Composable
private fun AnimeListRow(anime: Anime, caption: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
        AsyncImage(model = anime.image, contentDescription = null, modifier = Modifier.size(68.dp, 92.dp), contentScale = ContentScale.Crop)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(anime.title, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(caption, fontSize = 12.sp, color = Muted, maxLines = 2)
        }
        Icon(Icons.Filled.ChevronRight, null, tint = Gold)
    }
}

@Composable
private fun DetailScreen(
    anime: Anime, store: GoldenHenStore,
    onBack: () -> Unit, onPlay: (StreamSource) -> Unit, onSaved: () -> Unit, onDownloads: () -> Unit,
    onOpenSite: (String) -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    var version by remember { mutableIntStateOf(0) }
    var sourceLabel by remember(anime.id) { mutableStateOf(store.watched(anime.id)?.source?.label ?: "Episode 1") }
    var streamUrl by remember(anime.id) { mutableStateOf(store.watched(anime.id)?.source?.url ?: "") }
    var subtitleUrl by remember(anime.id) { mutableStateOf(store.watched(anime.id)?.source?.subtitleUrl ?: "") }
    var feedback by remember { mutableStateOf("") }
    val watchlisted = remember(version, anime.id) { store.saved("watchlist").any { it.id == anime.id } }
    val favorite = remember(version, anime.id) { store.saved("favorites").any { it.id == anime.id } }
    val canPlay = streamUrl.startsWith("https://", ignoreCase = true)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Box {
            AsyncImage(model = anime.banner.ifBlank { anime.image }, contentDescription = null,
                modifier = Modifier.fillMaxWidth().height(210.dp), contentScale = ContentScale.Crop)
            IconButton(onClick = onBack, modifier = Modifier.align(Alignment.TopStart).padding(12.dp).background(Ink.copy(alpha = .85f), RoundedCornerShape(100))) {
                Icon(Icons.Filled.ArrowBack, "Back", tint = Gold)
            }
        }
        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Text(anime.title, fontSize = 28.sp, fontWeight = FontWeight.Black, lineHeight = 33.sp)
            Text(listOfNotNull(anime.year.takeIf { it > 0 }?.toString(), anime.format, anime.status.replace('_', ' '), anime.episodes.takeIf { it > 0 }?.let { "$it episodes" }).filter { it.isNotBlank() }.joinToString("  ·  "), color = Muted, fontSize = 12.sp)
            if (anime.score > 0) Text("★  ${anime.score}% AniList score", color = Gold, fontWeight = FontWeight.Bold)
            Text(anime.genres.joinToString(" · "), color = Muted, fontSize = 13.sp)
            Text(anime.description.ifBlank { "No synopsis available." }, fontSize = 14.sp, lineHeight = 21.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { store.toggle("watchlist", anime); version++; onSaved() }) {
                    Icon(if (watchlisted) Icons.Filled.Check else Icons.Filled.Add, null)
                    Spacer(Modifier.width(6.dp)); Text(if (watchlisted) "In watchlist" else "Watchlist")
                }
                OutlinedButton(onClick = { store.toggle("favorites", anime); version++; onSaved() }) {
                    Icon(if (favorite) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null)
                    Spacer(Modifier.width(6.dp)); Text("Favorite")
                }
            }
            HorizontalDivider(color = Color(0xFF383240))
            Text("Episode guide", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            EpisodeGuide(anime = anime, onOpenSite = { onOpenSite(anime.title) })
            Text("Streaming availability", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text("AniList reports ${anime.episodes.takeIf { it > 0 }?.toString() ?: "an unknown number of"} total episodes. " +
                "This is metadata, not confirmation that each episode is released or playable.", color = Muted, fontSize = 12.sp)
            Text("Play an authorized source", fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text("Catalog information comes from AniList. Paste a video link you own or have permission to stream; the catalog does not provide episode streams.", color = Muted, fontSize = 12.sp)
            OutlinedTextField(value = sourceLabel, onValueChange = { sourceLabel = it }, label = { Text("Episode / movie label") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            OutlinedTextField(value = streamUrl, onValueChange = { streamUrl = it.trim() }, label = { Text("HTTPS stream URL (MP4 or HLS)") }, placeholder = { Text("https://...") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = subtitleUrl, onValueChange = { subtitleUrl = it.trim() }, label = { Text("Optional subtitle URL (.vtt / .srt)") }, modifier = Modifier.fillMaxWidth())
            Button(onClick = { onPlay(StreamSource(streamUrl, sourceLabel.ifBlank { "Video" }, subtitleUrl)) }, enabled = canPlay, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.PlayArrow, null); Spacer(Modifier.width(7.dp)); Text("Play video")
            }
            OutlinedButton(onClick = {
                val result = store.download(context, anime, StreamSource(streamUrl, sourceLabel.ifBlank { "Video" }, subtitleUrl))
                feedback = result.fold({ "Download queued. View it in Offline." }, { it.message ?: "Download unavailable" })
            }, enabled = canPlay, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.Download, null); Spacer(Modifier.width(7.dp)); Text("Download MP4 for offline viewing")
            }
            if (feedback.isNotBlank()) Text(feedback, color = Gold, fontSize = 12.sp)
            OutlinedButton(onClick = {
                if (canPlay) {
                    store.saveEpisode(anime.id, StreamSource(streamUrl, sourceLabel.ifBlank { "Episode" }, subtitleUrl))
                    version++
                    feedback = "Episode saved to this device."
                }
            }, enabled = canPlay, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Filled.PlaylistAdd, null)
                Spacer(Modifier.width(7.dp))
                Text("Save link to episode queue")
            }
            val queuedEpisodes = remember(version, anime.id) { store.episodes(anime.id) }
            if (queuedEpisodes.isNotEmpty()) {
                Text("Your episode queue", color = Gold, fontWeight = FontWeight.Bold)
                Text("Save episodes in playback order. These are your own links, not a third-party stream catalog.", color = Muted, fontSize = 11.sp)
                queuedEpisodes.forEach { episode ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { onPlay(episode) }, modifier = Modifier.weight(1f)) {
                            Icon(Icons.Filled.PlayArrow, null)
                            Text(episode.label, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        IconButton(onClick = { store.removeEpisode(anime.id, episode.url); version++ }) {
                            Icon(Icons.Filled.DeleteOutline, "Remove saved episode", tint = Muted)
                        }
                    }
                }
            }
            TextButton(onClick = onDownloads) { Text("Open offline library") }
        }
    }
}

@Composable
private fun OfflineScreen(store: GoldenHenStore, version: Int, onSelect: (Anime, String, String) -> Unit) {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    val saved = remember(version, refresh) { store.downloads() }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        SectionTitle("Offline library", "Completed direct MP4 downloads are playable without internet.")
        OutlinedButton(onClick = { refresh++ }) { Icon(Icons.Filled.Refresh, null); Spacer(Modifier.width(6.dp)); Text("Refresh downloads") }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(saved, key = { it.downloadId }) { entry ->
                val (status, uri) = remember(entry.downloadId, refresh) { store.offlineStatus(context, entry) }
                val label = when (status) {
                    DownloadManager.STATUS_SUCCESSFUL -> "Ready to watch"
                    DownloadManager.STATUS_RUNNING -> "Downloading"
                    DownloadManager.STATUS_PENDING -> "Queued"
                    DownloadManager.STATUS_PAUSED -> "Paused"
                    DownloadManager.STATUS_FAILED -> "Failed — please retry from the title"
                    else -> "Download no longer available"
                }
                AnimeListRow(entry.anime, "${entry.label} · $label") {
                    if (uri != null) onSelect(entry.anime, uri, entry.label)
                }
            }
            if (saved.isEmpty()) item { Text("No downloaded videos yet.", color = Muted) }
        }
    }
}

