package com.goldenhen.anime

import android.app.Application
import android.content.Context
import android.os.Process
import android.util.Log
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.io.PrintWriter
import java.io.StringWriter
import kotlin.system.exitProcess

/**
 * Capture an Android crash so a phone-only tester can share the actual stack trace
 * without connecting ADB. This does not conceal or automatically restart crashes.
 */
internal object CrashDiagnostics {
    private const val PREF_NAME = "goldenhen_crash_diagnostics"
    private const val LAST_CRASH = "last_crash"

    fun lastCrash(context: Context): String? =
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .getString(LAST_CRASH, null)?.takeIf { it.isNotBlank() }

    fun clear(context: Context) {
        context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
            .edit().remove(LAST_CRASH).apply()
    }

    fun install(context: Context) {
        val appContext = context.applicationContext
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val writer = StringWriter()
                throwable.printStackTrace(PrintWriter(writer))
                val report = buildString {
                    appendLine("Golden Hen ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
                    appendLine("Device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}")
                    appendLine("Android: ${android.os.Build.VERSION.RELEASE} (API ${android.os.Build.VERSION.SDK_INT})")
                    appendLine("Thread: ${thread.name}")
                    appendLine("Time: ${System.currentTimeMillis()}")
                    appendLine()
                    append(writer.toString().take(25000))
                }
                // Synchronous write is intentional: the process is about to terminate.
                appContext.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
                    .edit().putString(LAST_CRASH, report).commit()
                Log.e("GoldenHenCrash", report)
            } catch (_: Throwable) { /* Delegate the original exception regardless. */ }
            if (previous != null) previous.uncaughtException(thread, throwable)
            else {
                Process.killProcess(Process.myPid())
                exitProcess(10)
            }
        }
    }
}

class GoldenHenApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        CrashDiagnostics.install(this)
    }
}

/** Crash-recovery UI starts *without* constructing the catalog, WebView or player. */
@Composable
internal fun CrashRecoveryScreen(onLaunch: () -> Unit) {
    val context = LocalContext.current
    val report = remember { CrashDiagnostics.lastCrash(context).orEmpty() }
    val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
    Column(
        Modifier.fillMaxSize().padding(22.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Golden Hen", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("A crash was detected on the previous launch. The report below identifies the error. Your watchlist and downloads have not been erased.")
        Button(onClick = {
            clipboard.setText(androidx.compose.ui.text.AnnotatedString(report))
        }, modifier = Modifier.fillMaxWidth()) { Text("Copy crash report") }
        OutlinedButton(onClick = {
            CrashDiagnostics.clear(context)
            onLaunch()
        }, modifier = Modifier.fillMaxWidth()) { Text("Try opening Golden Hen") }
        Text("Crash details", style = MaterialTheme.typography.titleMedium)
        SelectionReport(report)
        Text("Copy the report above and paste it into the chat so the specific crashing line can be fixed.",
            style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun SelectionReport(report: String) {
    Text(report.ifBlank { "No report available." }, style = MaterialTheme.typography.bodySmall)
}
