# Golden Hen v0.3.2 — crash diagnostic update

This is the **v0.3.2 Android source project** for use with the existing `Golden-hen-anime` GitHub repository and `.github/workflows/main.yml`.

## Confirmed status

- Golden rooster launcher icon **already works** and was retained without alteration.
- Android has reported **Golden Hen keeps stopping** for the previous installed build.
- A screenshot of the standard Android crash dialog does not reveal the underlying exception or crashing code line. **The actual root cause has not been established**.

## Changes in v0.3.2

- Adds `GoldenHenApplication` and `CrashDiagnostics` to save an uncaught exception stack trace locally in private app storage when Android terminates the app.
- On the **next launch after a crash occurring in v0.3.2**, a lightweight recovery screen lets the user copy the actual error report and try opening the app again, without clearing their watchlist.
- Adds visible v0.3.2 indicator and new versionCode=5; old ZIP archives are rejected by the GitHub Actions workflow.
- Retains the gold rooster launcher icon and existing UI, anime metadata, Jikan episode guide, Animepahe website tab, and Aurora Media-style player.
- Explicitly enables `BuildConfig` for crash report version info.

## Limits and testing

This is a **diagnostic/stability update**, not a proven fix for the crash shown in the screenshot. We need the report (or `FATAL EXCEPTION` from Android logcat) to identify the actual cause. The first launch of v0.3.2 will attempt to open the normal app; if it crashes, reopen Golden Hen, tap **Copy crash report**, and paste it into ChatGPT. The diagnostic itself does not fix errors or prevent Android from closing the process.

No Android SDK or network-resolving Gradle build environment is available here. The source archive and YAML are validated locally, but Android compilation and device behavior **have not been verified**. GitHub Actions will perform the compilation test.

## GitHub ZIP workflow

1. Upload the **ZIP itself**, with exact name `GoldenHen_v0.3.2_GitHub_Source.zip`, to the **root** of your existing repository.
2. In `.github/workflows/main.yml`, replace the old workflow with the one supplied alongside this ZIP; **uploading the ZIP alone does not update your active workflow**.
3. Commit changes and run Actions → Build Golden Hen APK.
4. Download artifact `GoldenHen-v0.3.2-debug-apk`. Install over the same package ID. No need to uninstall, so local lists and crash reporting storage are preserved.
5. If the build fails, share the first meaningful Gradle error. If installation succeeds but Golden Hen crashes, reopen it and copy the crash report.

## Content source note

AniList and Jikan supply anime metadata and episode-guide information, not playable streams. The Animepahe tab opens the website but does not integrate its video stream URLs into native Media3. This update **does not add automatic episode streaming**.
