# Golden Hen — Android Anime App (v0.1 starter)

Modern dark-and-gold, no-account Android anime catalog and player. Kotlin + Jetpack Compose + Media3.

## What works in this starter

- Anime metadata lookup through AniList GraphQL; searchable catalog, paging and filters for genre, release year, format (TV/movie/OVA/ONA/special), airing status and sorting.
- Watchlist, favorites, history and continue-watching saved locally on your device (no login).
- Internal Media3 ExoPlayer with HLS/MP4 playback, playback speed, basic external SRT/WebVTT subtitle support, caption toggle, brightness and volume controls.
- DownloadManager support for authorized **direct HTTPS MP4 files**. Downloaded files remain in application-specific local storage; Offline tab plays completed files.
- Mobile-first, portrait browsing and landscape playback.
- GitHub Actions debug APK build.

## Limitations / coming next

- **Anime metadata does not mean licensed video access.** AniList is for discovering titles, not a video-streaming provider.
- Provide your **own authorized HTTPS MP4 or HLS link** from a title's detail screen. Do not enter access-controlled streams you lack permission to use.
- Offline download is limited to direct .mp4 HTTPS links. HLS/DASH manifests, DRM downloads, background retries, disk quota control, subtitle packages and download deletion UI are not implemented.
- 2K/4K video plays only where the stream, codec, Android device hardware and network permit it.
- No dubbed/subbed source discovery or language selection unless the supplied stream contains multiple tracks. Media3 can present native audio/text track choices if included in the source.
- No provider-specific episode listings, exact airing calendar, or automatic licensed-stream discovery yet.
- You can browse catalog online without signing in. Offline browsing metadata cache has not been built.
- This is a source-code starter. Actual APK compilation/runtime validation has **not** been performed in this environment.

## Build APK via GitHub (no local Android Studio required)

1. Create an empty GitHub repo (e.g. `GoldenHen`).
2. Upload **the contents** of `GoldenHen_Android_Repo` to the repository root, including `.github/workflows/build-apk.yml`.
3. Go to the repository's **Actions** tab -> **Build Golden Hen APK** -> **Run workflow** (or push to `main`).
4. Once the workflow succeeds, download the artifact `GoldenHen-debug-apk` and install the APK on an Android device.
5. If GitHub reports a Gradle dependency/build error, share the full log so it can be resolved; this scaffold hasn't been built locally.

## Local build

Requires Android SDK Platform 35, JDK 17 and Gradle 8.11.1. In the repository root run:

```bash
gradle assembleDebug
```

## External anime API integration

You supplied:

```bash
git clone https://github.com/pal-droid/Animepahe-api.git
cd Animepahe-api
```

That repository's contents and license have **not been inspected or verified** in this environment. It is NOT bundled or secretly queried by Golden Hen. To assess compatibility, provide an archive of its source or documented API contract.

The `EpisodeProvider` interface in `AnimeData.kt` is the integration seam. Any added service must supply stable documented endpoints and streams the app is authorized to access. Keep provider-specific logic out of the UI and do not ship scraped third-party streaming cookies/keys.

## Privacy

- AniList receives queries to display anime metadata.
- Source URLs you enter are accessed by the player's network stack, or by Android DownloadManager for direct MP4 downloads.
- Saved lists and playback history reside in unencrypted local app preferences, not a cloud account. Do not enter sensitive authenticated URLs.

## Licensing and branding

No anime episode video files, copyrighted artwork archives, Animepahe source code, access tokens, or unofficial scraping logic are included. Cover images are loaded from AniList metadata URLs while online. Review API terms and rightsholder permissions before redistribution.
