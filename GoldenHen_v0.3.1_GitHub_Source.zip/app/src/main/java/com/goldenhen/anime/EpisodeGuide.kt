package com.goldenhen.anime

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Jikan provides episode metadata only. It is not a video or streaming API. */
internal data class EpisodeEntry(val number: Int, val title: String, val aired: String)
internal data class EpisodePage(val entries: List<EpisodeEntry>, val hasNext: Boolean)

internal object EpisodeGuideApi {
    private val client = OkHttpClient.Builder().callTimeout(20, TimeUnit.SECONDS).build()
    fun load(malId: Int, page: Int): EpisodePage {
        require(malId > 0 && page > 0)
        val request = Request.Builder()
            .url("https://api.jikan.moe/v4/anime/$malId/episodes?page=$page")
            .header("Accept", "application/json")
            .get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) error("Episode guide unavailable (HTTP ${response.code}). Try again later.")
            val json = JSONObject(response.body?.string() ?: "{}")
            val data = json.optJSONArray("data") ?: error("No episode data returned")
            val entries = (0 until data.length()).mapNotNull { index ->
                val item = data.optJSONObject(index) ?: return@mapNotNull null
                EpisodeEntry(
                    number = item.optInt("mal_id", 0),
                    title = item.optString("title").takeUnless { it.isBlank() || it == "null" } ?: "Episode ${item.optInt("mal_id", 0)}",
                    aired = item.optString("aired").takeUnless { it == "null" }?.take(10).orEmpty()
                )
            }
            return EpisodePage(entries, json.optJSONObject("pagination")?.optBoolean("has_next_page") == true)
        }
    }
}

@Composable
internal fun EpisodeGuide(anime: Anime, onOpenSite: () -> Unit) {
    var page by remember(anime.id) { mutableIntStateOf(1) }
    var entries by remember(anime.id) { mutableStateOf<List<EpisodeEntry>>(emptyList()) }
    var hasNext by remember(anime.id) { mutableStateOf(false) }
    var loading by remember(anime.id) { mutableStateOf(false) }
    var error by remember(anime.id) { mutableStateOf<String?>(null) }
    var retry by remember(anime.id) { mutableIntStateOf(0) }

    if (anime.malId <= 0) {
        Text("No MyAnimeList ID available for the episode guide. You can check the provider website for released episodes.", color = Color(0xFFAEA8BC), fontSize = 12.sp)
        return
    }

    LaunchedEffect(anime.malId, page, retry) {
        loading = true
        error = null
        try {
            val result = withContext(Dispatchers.IO) { EpisodeGuideApi.load(anime.malId, page) }
            entries = if (page == 1) result.entries else (entries + result.entries).distinctBy { it.number }
            hasNext = result.hasNext
        } catch (e: Exception) {
            error = e.message ?: "Episode guide unavailable"
        } finally { loading = false }
    }

    Text("Episode titles and air dates are supplied by Jikan/MyAnimeList. These are NOT playable videos and may not include the latest releases.", color = Color(0xFFAEA8BC), fontSize = 12.sp)
    entries.forEach { episode ->
        Surface(color = Color(0xFF25202B), shape = RoundedCornerShape(11.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("Episode ${episode.number}: ${episode.title}", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                Text(if (episode.aired.isNotBlank()) "Air date: ${episode.aired}" else "Air date not listed", color = Color(0xFFAEA8BC), fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(6.dp))
    }
    if (loading) CircularProgressIndicator(color = Color(0xFFFFCB58), modifier = Modifier.size(24.dp))
    if (error != null) {
        Text(error!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
        TextButton(onClick = { retry++ }) { Text("Retry episode guide") }
    }
    if (!loading && hasNext) {
        OutlinedButton(onClick = { page++ }, modifier = Modifier.fillMaxWidth()) { Text("Load more episode titles") }
    }
    OutlinedButton(onClick = onOpenSite, modifier = Modifier.fillMaxWidth()) {
        Icon(Icons.Filled.Language, contentDescription = null)
        Spacer(Modifier.width(8.dp))
        Text("Browse available episodes on Animepahe")
    }
}
