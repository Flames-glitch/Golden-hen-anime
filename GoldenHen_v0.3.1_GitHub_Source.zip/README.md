# Golden Hen v0.3.1 — Android source

## Fixes since v0.3

- Unique **v0.3.1** badge in the header and versionName `0.3.1`, versionCode 4. This is how to confirm that an updated APK, not an older V2 artifact, was installed.
- **Golden rooster icon** embedded in launcher mipmap resources, adaptive icon, manifest, and **inside the app header**.
- **Episode guide from Jikan**: AniList `idMal` is carried into saved anime records; `https://api.jikan.moe/v4/anime/{idMal}/episodes?page=N` supplies episode titles and reported air dates, with pagination and basic error handling. Jikan is unofficial and may lack or lag episodes.
- **Animepahe website tab** opens user-supplied `animepahe.ng` or `animepahe.ch` in a WebView with external-browser fallback. This shows live website episode pages; website playback is managed by the site, not Media3.
- The **GitHub YAML refuses to build any older ZIP**. It selects *only* the exact file `GoldenHen_v0.3.1_GitHub_Source.zip` at the repository root; it checks for the icon, episode guide, and version before building.

## Not yet supported

- Native automatic video streams from Animepahe. There is no provider-specific episode-to-stream resolver in this project. The native player continues to accept user-provided authorized HTTPS MP4/HLS sources.
- Confirmation that every episode across Animepahe is listed in the native guide. Jikan/MAL metadata is separate from the site's availability.
- Automatic mirror discovery or site changes while the app is closed.

## Android GitHub upload workflow

1. Upload **the exact ZIP filename** `GoldenHen_v0.3.1_GitHub_Source.zip` as a file at the existing GitHub repo root.
2. Replace the repository's `.github/workflows/main.yml` with the YAML supplied separately (and included inside the ZIP). **Uploading the ZIP does not update the active repository YAML**.
3. Commit both. The workflow extracts that ZIP and refuses older archives.
4. In Actions, build `GoldenHen-v0.3.1-debug-apk`, then install the APK. Look for the rooster icon and the `v0.3.1` badge on the app header.

## Testing limits

The archive, file references, manifest, and YAML are checked locally. No Android SDK / network dependency resolver is available in this environment, so an actual APK build and playback verification require a GitHub Actions compilation test and device test.
